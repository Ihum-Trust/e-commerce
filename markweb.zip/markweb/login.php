<?php
if($_POST){
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $dbname = "login_form";
    
    $connection = mysqli_connect("localhost", "root", "", 'login_form');
    
    $sql = "INSERT INTO `usb` (`username`, `email`, `password`) VALUES ('$username', '$email', '$password')";
    
    $query = mysqli_query($connection,$sql);
    if($query){
     echo "You have successfully registered";
    }
    
    else{
        echo "There was an error with details";
    }
}
?>