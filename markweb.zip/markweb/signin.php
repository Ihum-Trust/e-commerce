<?php
if($_POST){
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $dbname = "sign_form";
    
    $connection = mysqli_connect("localhost", "root", "", 'sign_form');
    
    $sql = "INSERT INTO `newsers` (`firstname`,`lastname`,`username`, `email`, `password`) VALUES ('$firstname','$lastname','$username', '$email', '$password')";
    
    $query = mysqli_query($connection,$sql);
    if($query){
     echo "You have successfully been registered";
    }
    
    else{
        echo "There was an error";
    }
}
?>